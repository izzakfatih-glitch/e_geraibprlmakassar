"""
Modul pembangun dokumen Word (proposal PKKPRL final) dari data & gambar
hasil ekstraksi (lihat extract.py).
"""
import io
import re
import time
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from llm_fallback import perkuat_narasi_ilmiah, buat_analisis_ekosistem

# Batas waktu KUMULATIF (detik) untuk SEMUA pemanggilan AI "pemanis narasi"
# (perkuat_narasi_ilmiah/buat_analisis_ekosistem) dalam SATU proses generate
# dokumen -- bisa dipanggil sampai 8x (mangrove/lamun/karang/ekosistem/
# gelombang/arus/pasut/batimetri). Walau tiap panggilan sudah dibatasi
# timeout masing-masing di llm_fallback.py, DELAPAN panggilan berurutan yang
# masing2 lambat tetap bisa menumpuk melebihi timeout worker gunicorn (300
# detik) -- terutama saat banyak pengguna memakai aplikasi bersamaan dan API
# jadi lebih lambat merespons. Begitu anggaran waktu ini habis, sisa
# panggilan "pemanis" yang belum sempat jalan DILEWATI (pakai teks
# asli/kalimat dasar apa adanya) supaya dokumen tetap PASTI selesai dibuat
# dan SEMUA data yang sudah benar diisi pengguna (koordinat, jadwal
# kegiatan, dst) tidak ikut hilang gara-gara satu bagian narasi yang lambat.
NARASI_TIME_BUDGET_SECONDS = 150

try:
    from PIL import Image as PILImage
except Exception:
    PILImage = None


def normalize_image_bytes(img_bytes):
    """Ubah bytes gambar apapun (hasil ekstraksi dari PDF/Word sumber, yang
    kadang formatnya tidak umum -- mis. JPEG CMYK, JPEG2000/JP2, atau format
    lain yang tidak dikenali python-docx) menjadi PNG standar yang PASTI bisa
    diterima python-docx's add_picture(). Kalau Pillow tidak bisa membuka
    bytes-nya sama sekali (benar-benar rusak/bukan gambar), return None
    supaya pemanggil bisa fallback ke placeholder alih-alih membuat SELURUH
    proses generate dokumen gagal gara-gara satu gambar bermasalah."""
    if not img_bytes:
        return None
    if PILImage is None:
        return img_bytes  # Pillow tak tersedia -- coba bytes asli apa adanya
    try:
        im = PILImage.open(io.BytesIO(img_bytes))
        im.load()
        if im.mode not in ("RGB", "RGBA"):
            im = im.convert("RGBA" if "A" in im.mode else "RGB")
        buf = io.BytesIO()
        im.save(buf, format="PNG")
        return buf.getvalue()
    except Exception:
        return None

NAVY = RGBColor(0x1F, 0x4E, 0x79)
LIGHTBLUE = "DCE6F1"
FONT = "Calibri"

NA = "[data tidak terdeteksi otomatis \u2013 mohon lengkapi manual]"


def g(d, key, default=NA):
    v = d.get(key)
    if v is None or v == "":
        return default
    return v


def format_luas_ha(value):
    """Tambahkan satuan 'Ha' otomatis kalau nilai luas yang diinput cuma
    berupa angka polos (mis. '0.25' atau '0,25' -> '0.25 Ha' / '0,25 Ha'),
    tanpa menduplikasi kalau user sudah mengetik satuannya sendiri."""
    if not value or value == NA:
        return value
    v = value.strip()
    if re.fullmatch(r"-?[\d.,]+", v):
        return f"{v} Ha"
    return v


# Kriteria baku kondisi ekosistem (sesuai dokumen resmi KRITERIA_KONDISI) --
# dipakai untuk otomatis menentukan label kondisi dari data persentase yang
# terbaca dari Laporan Hidro-Oseanografi (bukan cuma input manual).
KRITERIA_KARANG_LAP = [(75, 999, "Baik Sekali"), (50, 75, "Baik"), (25, 50, "Sedang"), (0, 25, "Buruk")]


def klasifikasi_karang(persen_str):
    try:
        v = float(str(persen_str).replace(",", ".").replace("%", "").strip())
    except (TypeError, ValueError):
        return ""
    for lo, hi, label in KRITERIA_KARANG_LAP:
        if lo <= v < hi:
            return label
    return ""


def _ada_data_numerik(v):
    """True kalau v adalah nilai numerik nyata (bukan placeholder NA, bukan
    kosong, dan bukan nol) -- dipakai untuk cek apakah data luas/persentase
    ekosistem dari Laporan Hidro-Oseanografi benar-benar terdeteksi, supaya
    narasi tidak salah mengklaim "hasil survei menunjukkan dijumpainya..."
    padahal datanya sendiri tidak ada/nol."""
    if not v or v == NA:
        return False
    try:
        return float(str(v).replace(",", ".").replace("%", "").replace("Ha", "").strip()) != 0
    except (TypeError, ValueError):
        return False


def shade_cell(cell, color_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), color_hex)
    tcPr.append(shd)


def strip_markdown_emphasis(text):
    """Buang penanda markdown (*tebal*, **tebal**) dari teks -- narasi hasil
    AI (perkuat_narasi_ilmiah/buat_analisis_ekosistem) kadang menghasilkan
    format markdown untuk nama ilmiah/istilah teknis (mis. '*Acropora
    cervicornis*'), tapi python-docx TIDAK merender markdown -- tanda
    bintang itu akan tampil literal di dokumen Word, bukan jadi cetak
    miring. Daripada mencoba menerjemahkan ke italic run terpisah (rumit
    untuk teks yang sudah jadi satu string panjang), tanda bintangnya
    dibuang saja supaya teksnya tetap bersih dan enak dibaca."""
    if not text:
        return text
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    text = re.sub(r"\*(.+?)\*", r"\1", text)
    return text


def flatten_ws(text):
    """Ratakan teks bebas dari form/textarea (yang mungkin berisi baris baru
    karena pengguna menekan Enter antar kalimat/poin) menjadi satu paragraf
    mengalir dengan spasi tunggal. PENTING untuk paragraf JUSTIFY: kalau baris
    baru mentah dibiarkan, python-docx mengubahnya jadi <w:br/> (line break)
    DI DALAM paragraf yang sama, sehingga Word men-stretch tiap baris pendek
    itu supaya rata kanan-kiri -- hasilnya spasi antar-kata jadi sangat lebar
    dan tidak rapi. Menyatukan jadi satu alur teks membuat Word membungkus
    baris secara alami berdasar lebar halaman, dan hanya baris TERAKHIR
    paragraf (yang secara default tidak di-stretch) yang rata kiri biasa.
    """
    if not text:
        return text
    text = strip_markdown_emphasis(str(text))
    return re.sub(r"\s+", " ", text).strip()


def set_font(run, size=11, bold=False, italic=False, color=None):
    run.font.name = FONT
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    if color:
        run.font.color.rgb = color
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.append(rFonts)
    rFonts.set(qn("w:eastAsia"), FONT)


BULAN_ID_KE_NOMOR = {
    "januari": 1, "februari": 2, "maret": 3, "april": 4, "mei": 5, "juni": 6,
    "juli": 7, "agustus": 8, "september": 9, "oktober": 10, "november": 11, "desember": 12,
}
BULAN_ID_SINGKAT = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Ags", "Sep", "Okt", "Nov", "Des"]


def parse_jadwal_kegiatan(text):
    """Uraikan teks 'Deskripsi Jadwal Kegiatan' menjadi daftar aktivitas.
    Format yang diharapkan (satu atau lebih, dipisah titik):
    "Nama Kegiatan : Bulan X - Bulan Y." Mengembalikan list of
    (nama_kegiatan, bulan_mulai, bulan_selesai). Kalau tidak ada yang cocok
    sama sekali, mengembalikan list kosong (pemanggil lalu memakai fallback
    teks polos biasa)."""
    if not text:
        return []
    pattern = re.compile(
        r"([^.:]+?)\s*:\s*Bulan\s*(\d+)\s*(?:-|s/d|sampai)\s*Bulan\s*(\d+)\s*\.?",
        re.IGNORECASE,
    )
    hasil = []
    for m in pattern.finditer(text):
        nama = m.group(1).strip(" .")
        try:
            mulai = int(m.group(2))
            selesai = int(m.group(3))
        except ValueError:
            continue
        if nama and selesai >= mulai:
            hasil.append((nama, mulai, selesai))
    return hasil


def parse_tanggal_indonesia(text):
    """Uraikan tanggal format 'D Bulan YYYY' (mis. '3 Agustus 2026') jadi
    (bulan, tahun). Mengembalikan None kalau gagal."""
    if not text:
        return None
    m = re.search(r"(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})", text)
    if not m:
        return None
    nama_bulan = m.group(2).strip().lower()
    bulan = BULAN_ID_KE_NOMOR.get(nama_bulan)
    if not bulan:
        return None
    return bulan, int(m.group(3))


def build_gantt_table(builder, activities, start_bulan_tahun):
    """Buat tabel Gantt chart (rencana jadwal pelaksanaan) mirip format resmi:
    baris tahun, baris bulan (Jan-Des disingkat), lalu 1 baris per kegiatan
    dengan sel yang diarsir gelap pada rentang bulan aktivitas tsb berjalan."""
    max_bulan = max(a[2] for a in activities)
    start_month, start_year = start_bulan_tahun

    # Bangun label kalender aktual untuk tiap "Bulan N" (N=1..max_bulan)
    kalender = []
    m, y = start_month, start_year
    for _ in range(max_bulan):
        kalender.append((BULAN_ID_SINGKAT[m - 1], y))
        m += 1
        if m > 12:
            m = 1
            y += 1

    doc = builder.doc
    ncols = 1 + max_bulan
    table = doc.add_table(rows=0, cols=ncols)
    table.style = "Table Grid"

    # Baris 1: label tahun (digabung/merge per kelompok tahun yang sama)
    row_year = table.add_row()
    shade_cell(row_year.cells[0], "1F4E79")
    row_year.cells[0].text = ""
    i = 0
    while i < max_bulan:
        y = kalender[i][1]
        j = i
        while j < max_bulan and kalender[j][1] == y:
            j += 1
        start_cell = row_year.cells[1 + i]
        if j - i > 1:
            end_cell = row_year.cells[1 + j - 1]
            start_cell = start_cell.merge(end_cell)
        shade_cell(start_cell, "1F4E79")
        p = start_cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(str(y))
        set_font(r, size=10, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))
        i = j

    # Baris 2: header "Kegiatan" + nama bulan singkat
    row_bulan = table.add_row()
    shade_cell(row_bulan.cells[0], "1F4E79")
    p0 = row_bulan.cells[0].paragraphs[0]
    r0 = p0.add_run("Kegiatan")
    set_font(r0, size=10, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))
    for i, (nama_bulan, _) in enumerate(kalender):
        cell = row_bulan.cells[1 + i]
        shade_cell(cell, "1F4E79")
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(nama_bulan)
        set_font(r, size=9.5, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))

    # Baris kegiatan
    for nama, mulai, selesai in activities:
        row = table.add_row()
        cell0 = row.cells[0]
        p0 = cell0.paragraphs[0]
        r0 = p0.add_run(nama)
        set_font(r0, size=9.5, bold=True)
        for i in range(max_bulan):
            bulan_ke = i + 1
            cell = row.cells[1 + i]
            cell.text = ""
            if mulai <= bulan_ke <= selesai:
                shade_cell(cell, "BFBFBF")

    # Lebar kolom: kolom "Kegiatan" lebih lebar, kolom bulan sempit & seragam
    table.columns[0].width = Cm(3.6)
    for i in range(max_bulan):
        table.columns[1 + i].width = Cm(1.0)
    for row in table.rows:
        row.cells[0].width = Cm(3.6)
        for i in range(max_bulan):
            row.cells[1 + i].width = Cm(1.0)

    return table


def build_gantt_table_weekly(builder, activities_minggu, start_bulan_tahun, max_bulan):
    """Versi tabel Gantt dengan presisi minggu (4 sub-kolom per bulan), dipakai
    otomatis kalau kolom Minggu Mulai/Selesai diisi di form -- supaya pewarnaan
    mengikuti persis minggu yang diisi, bukan cuma satu bulan penuh. Tampilan
    tetap mengikuti format resmi (baris tahun, baris bulan), hanya ditambah
    satu baris nomor minggu (1-4) dan kolom lebih sempit per minggu."""
    max_minggu = max_bulan * 4
    start_month, start_year = start_bulan_tahun

    kalender = []
    m, y = start_month, start_year
    for _ in range(max_bulan):
        kalender.append((BULAN_ID_SINGKAT[m - 1], y))
        m += 1
        if m > 12:
            m = 1
            y += 1

    doc = builder.doc
    ncols = 1 + max_minggu
    table = doc.add_table(rows=0, cols=ncols)
    table.style = "Table Grid"

    # Baris 1: label tahun (merge per kelompok bulan x4 minggu dalam tahun yang sama)
    row_year = table.add_row()
    shade_cell(row_year.cells[0], "1F4E79")
    row_year.cells[0].text = ""
    i = 0
    while i < max_bulan:
        y = kalender[i][1]
        j = i
        while j < max_bulan and kalender[j][1] == y:
            j += 1
        start_cell = row_year.cells[1 + i * 4]
        end_cell = row_year.cells[1 + j * 4 - 1]
        merged = start_cell.merge(end_cell) if end_cell != start_cell else start_cell
        shade_cell(merged, "1F4E79")
        p = merged.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(str(y))
        set_font(r, size=10, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))
        i = j

    # Baris 2: nama bulan (merge tiap 4 kolom minggu)
    row_bulan = table.add_row()
    shade_cell(row_bulan.cells[0], "1F4E79")
    for i, (nama_bulan, _) in enumerate(kalender):
        start_cell = row_bulan.cells[1 + i * 4]
        end_cell = row_bulan.cells[1 + i * 4 + 3]
        merged = start_cell.merge(end_cell)
        shade_cell(merged, "1F4E79")
        p = merged.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(nama_bulan)
        set_font(r, size=9, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))

    # Baris 3: header "Kegiatan" + nomor minggu 1-4 berulang tiap bulan
    row_minggu = table.add_row()
    shade_cell(row_minggu.cells[0], "1F4E79")
    p0 = row_minggu.cells[0].paragraphs[0]
    r0 = p0.add_run("Kegiatan")
    set_font(r0, size=10, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))
    for i in range(max_minggu):
        cell = row_minggu.cells[1 + i]
        shade_cell(cell, "2E5E96")
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(str((i % 4) + 1))
        set_font(r, size=8, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))

    # Baris kegiatan
    for nama, mulai, selesai in activities_minggu:
        row = table.add_row()
        cell0 = row.cells[0]
        p0 = cell0.paragraphs[0]
        r0 = p0.add_run(nama)
        set_font(r0, size=9.5, bold=True)
        for i in range(max_minggu):
            minggu_ke = i + 1
            cell = row.cells[1 + i]
            cell.text = ""
            if mulai <= minggu_ke <= selesai:
                shade_cell(cell, "BFBFBF")

    table.columns[0].width = Cm(3.6)
    for i in range(max_minggu):
        table.columns[1 + i].width = Cm(0.42)
    for row in table.rows:
        row.cells[0].width = Cm(3.6)
        for i in range(max_minggu):
            row.cells[1 + i].width = Cm(0.42)

    return table


class Builder:
    def __init__(self):
        self.doc = Document()
        style = self.doc.styles["Normal"]
        style.font.name = FONT
        style.font.size = Pt(11)
        section = self.doc.sections[0]
        section.left_margin = Cm(2.5)
        section.right_margin = Cm(2.0)
        section.top_margin = Cm(2.0)
        section.bottom_margin = Cm(2.0)

    def h1(self, text):
        p = self.doc.add_paragraph()
        p.paragraph_format.space_before = Pt(14)
        p.paragraph_format.space_after = Pt(8)
        r = p.add_run(text)
        set_font(r, size=15, bold=True, color=NAVY)
        return p

    def h2(self, text):
        p = self.doc.add_paragraph()
        p.paragraph_format.space_before = Pt(12)
        p.paragraph_format.space_after = Pt(6)
        r = p.add_run(text)
        set_font(r, size=13, bold=True, color=NAVY)
        return p

    def h3(self, text):
        p = self.doc.add_paragraph()
        p.paragraph_format.space_before = Pt(10)
        p.paragraph_format.space_after = Pt(4)
        r = p.add_run(text)
        set_font(r, size=12, bold=True)
        return p

    def p(self, text, italic=False, justify=True):
        para = self.doc.add_paragraph()
        para.paragraph_format.space_after = Pt(8)
        para.paragraph_format.line_spacing = 1.25
        if justify:
            para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        r = para.add_run(flatten_ws(text))
        set_font(r, size=11, italic=italic)
        return para

    def labeled(self, label, text):
        para = self.doc.add_paragraph()
        para.paragraph_format.space_after = Pt(8)
        para.paragraph_format.line_spacing = 1.25
        para.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        r1 = para.add_run(label + ": ")
        set_font(r1, size=11, bold=True)
        r2 = para.add_run(flatten_ws(text))
        set_font(r2, size=11)
        return para

    def bullet(self, text):
        para = self.doc.add_paragraph(style="List Bullet")
        r = para.add_run(text)
        set_font(r, size=11)
        return para

    def bullet_with_link(self, prefix_text, link_text, url, suffix_text=""):
        """Bullet list yang bagian tautannya (mis. link Google Drive) dibuat
        sebagai hyperlink asli yang bisa diklik di Word, bukan cuma teks
        biasa. python-docx belum punya API bawaan untuk hyperlink, jadi
        dibangun manual lewat XML (w:hyperlink + relationship id)."""
        para = self.doc.add_paragraph(style="List Bullet")
        if prefix_text:
            r0 = para.add_run(prefix_text)
            set_font(r0, size=11)

        part = para.part
        r_id = part.relate_to(
            url,
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
            is_external=True,
        )
        hyperlink = OxmlElement("w:hyperlink")
        hyperlink.set(qn("r:id"), r_id)
        new_run = OxmlElement("w:r")
        rpr = OxmlElement("w:rPr")
        color = OxmlElement("w:color")
        color.set(qn("w:val"), "1155CC")
        rpr.append(color)
        u = OxmlElement("w:u")
        u.set(qn("w:val"), "single")
        rpr.append(u)
        rfonts = OxmlElement("w:rFonts")
        rfonts.set(qn("w:ascii"), FONT)
        rfonts.set(qn("w:hAnsi"), FONT)
        rpr.append(rfonts)
        sz = OxmlElement("w:sz")
        sz.set(qn("w:val"), "22")
        rpr.append(sz)
        new_run.append(rpr)
        t = OxmlElement("w:t")
        t.text = link_text
        new_run.append(t)
        hyperlink.append(new_run)
        para._p.append(hyperlink)

        if suffix_text:
            r2 = para.add_run(suffix_text)
            set_font(r2, size=11)
        return para

    def caption(self, text):
        para = self.doc.add_paragraph()
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        para.paragraph_format.space_after = Pt(12)
        r = para.add_run(text)
        set_font(r, size=10, italic=True)
        return para

    def image(self, img_bytes, width_cm=14):
        """Sisipkan gambar ke dokumen. Bytes-nya dinormalisasi ke PNG dulu
        (lihat normalize_image_bytes) supaya format gambar apapun dari
        sumber (JPEG CMYK, JP2, dsb) tetap bisa diterima python-docx.
        Return paragraf-nya kalau berhasil, atau None kalau gambarnya
        benar-benar tidak bisa dibaca/rusak -- pemanggil sebaiknya
        melewatkan caption terkait kalau return-nya None, supaya tidak ada
        caption "menggantung" tanpa gambar di atasnya."""
        safe_bytes = normalize_image_bytes(img_bytes)
        if safe_bytes is None:
            return None
        para = self.doc.add_paragraph()
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = para.add_run()
        try:
            run.add_picture(io.BytesIO(safe_bytes), width=Cm(width_cm))
        except Exception:
            return None
        return para

    def page_break(self):
        self.doc.add_page_break()

    def kv_table(self, rows, col_widths_cm=(5.0, 10.0)):
        table = self.doc.add_table(rows=0, cols=2)
        table.style = "Table Grid"
        for k, v in rows:
            row = table.add_row()
            row.cells[0].width = Cm(col_widths_cm[0])
            row.cells[1].width = Cm(col_widths_cm[1])
            p0 = row.cells[0].paragraphs[0]
            r0 = p0.add_run(k)
            set_font(r0, size=10.5, bold=True)
            shade_cell(row.cells[0], LIGHTBLUE)
            row.cells[0].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            p1 = row.cells[1].paragraphs[0]
            r1 = p1.add_run(str(v))
            set_font(r1, size=10.5)
            row.cells[1].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        return table

    def data_table(self, header, rows, header_color=None):
        header_color = header_color or "1F4E79"
        ncols = len(header)
        table = self.doc.add_table(rows=0, cols=ncols)
        table.style = "Table Grid"
        hrow = table.add_row()
        for i, htext in enumerate(header):
            cell = hrow.cells[i]
            shade_cell(cell, header_color)
            para = cell.paragraphs[0]
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = para.add_run(htext)
            set_font(r, size=10.5, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        for row_vals in rows:
            row = table.add_row()
            for i, val in enumerate(row_vals):
                cell = row.cells[i]
                para = cell.paragraphs[0]
                if i > 0:
                    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                r = para.add_run(flatten_ws(str(val)))
                set_font(r, size=10.5)
                cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        return table

    def save(self, path):
        self.doc.save(path)


def get_image_bytes(images, tag, nth=0):
    matches = [im for im in images if im["tag"] == tag]
    if len(matches) > nth:
        return matches[nth]["bytes"]
    return None


def activities_from_jadwal_table(jadwal_table):
    """Ubah data tabel jadwal terstruktur (list of dict berisi nama, tahun_mulai,
    bulan_mulai, tahun_selesai, bulan_selesai, dan minggu_mulai/minggu_selesai
    opsional -- masing2 dari input tabel form) menjadi data siap pakai untuk
    build_gantt_table / build_gantt_table_weekly. 'anchor' otomatis diambil dari
    tanggal paling awal di antara semua kegiatan, jadi mendukung rentang lebih
    dari 1 tahun tanpa perlu field tanggal referensi terpisah.

    Mengembalikan tuple:
    (activities_bulan, activities_minggu, anchor_bulan_tahun, rincian, ada_detail_minggu)
    - activities_bulan: list (nama, bulan_mulai_rel, bulan_selesai_rel) -- presisi bulan,
      dipakai kalau TIDAK ada satupun kegiatan yang diisi kolom Minggu.
    - activities_minggu: list (nama, minggu_mulai_rel, minggu_selesai_rel) -- presisi
      minggu (1 bulan = 4 minggu relatif terhadap anchor), dipakai kalau ADA kegiatan
      yang diisi kolom Minggu, supaya pewarnaan Gantt chart mengikuti persis apa yang
      diisi di form (minggu tertentu, bukan satu bulan penuh).
    - rincian: list [nama, teks_mulai, teks_selesai] siap tampil sebagai tabel rincian.
    - ada_detail_minggu: True kalau minimal satu kegiatan mengisi Minggu Mulai/Selesai.
    """
    if not jadwal_table:
        return [], [], None, [], False

    def abs_month(tahun, bulan):
        return int(tahun) * 12 + int(bulan)

    valid = []
    for row in jadwal_table:
        try:
            am1 = abs_month(row["tahun_mulai"], row["bulan_mulai"])
            am2 = abs_month(row["tahun_selesai"], row["bulan_selesai"])
        except (KeyError, ValueError, TypeError):
            continue
        if am2 < am1:
            am1, am2 = am2, am1
        valid.append((row, am1, am2))
    if not valid:
        return [], [], None, [], False

    anchor_abs = min(v[1] for v in valid)
    anchor_year, anchor_month = divmod(anchor_abs - 1, 12)
    anchor_month += 1

    def minggu_int(v, default):
        try:
            n = int(v)
            return n if 1 <= n <= 4 else default
        except (TypeError, ValueError):
            return default

    ada_detail_minggu = any((row.get("minggu_mulai") or row.get("minggu_selesai")) for row, _, _ in valid)

    activities_bulan = []
    activities_minggu = []
    rincian = []
    for row, am1, am2 in valid:
        mulai_rel = am1 - anchor_abs + 1
        selesai_rel = am2 - anchor_abs + 1
        nama = row.get("nama", "").strip() or "-"
        activities_bulan.append((nama, mulai_rel, selesai_rel))

        mg1 = minggu_int(row.get("minggu_mulai"), 1)
        mg2 = minggu_int(row.get("minggu_selesai"), 4)
        mulai_minggu_rel = (mulai_rel - 1) * 4 + mg1
        selesai_minggu_rel = (selesai_rel - 1) * 4 + mg2
        activities_minggu.append((nama, mulai_minggu_rel, selesai_minggu_rel))

        bl1_nama = BULAN_ID_SINGKAT[(int(row["bulan_mulai"]) - 1) % 12]
        bl2_nama = BULAN_ID_SINGKAT[(int(row["bulan_selesai"]) - 1) % 12]
        mg1_txt = row.get("minggu_mulai") or ""
        mg2_txt = row.get("minggu_selesai") or ""
        mulai_txt = f"{bl1_nama}" + (f" Mgu-{mg1_txt}" if mg1_txt else "") + f" {row['tahun_mulai']}"
        selesai_txt = f"{bl2_nama}" + (f" Mgu-{mg2_txt}" if mg2_txt else "") + f" {row['tahun_selesai']}"
        rincian.append([nama, mulai_txt, selesai_txt])

    return activities_bulan, activities_minggu, (anchor_month, anchor_year), rincian, ada_detail_minggu



def build_document(prop, prop_imgs, lap, lap_imgs, output_path):
    b = Builder()

    # Lihat catatan NARASI_TIME_BUDGET_SECONDS di atas -- anggaran waktu
    # kumulatif untuk semua panggilan AI "pemanis narasi" di bawah.
    _narasi_deadline = time.time() + NARASI_TIME_BUDGET_SECONDS

    def _enhance_ekosistem(jenis, spesies, persentase, kondisi, konteks_lokasi=""):
        if time.time() >= _narasi_deadline:
            return ""
        return buat_analisis_ekosistem(jenis, spesies, persentase, kondisi, konteks_lokasi)

    def _enhance_narasi(teks_asli, konteks=""):
        if time.time() >= _narasi_deadline:
            return teks_asli
        return perkuat_narasi_ilmiah(teks_asli, konteks=konteks)

    lokasi_parts = prop.get("_lokasi_parts") or []
    desa = lokasi_parts[0] if len(lokasi_parts) > 0 else g(prop, "_desa")
    kecamatan = lokasi_parts[1] if len(lokasi_parts) > 1 else desa
    kabupaten = lokasi_parts[2] if len(lokasi_parts) > 2 else NA
    provinsi = lokasi_parts[3] if len(lokasi_parts) > 3 else NA
    lokasi_lengkap = f"Desa {desa}, Kecamatan {kecamatan}, {kabupaten}, Provinsi {provinsi}"

    perusahaan = g(prop, "Nama Perusahaan/Instansi")
    perairan = g(prop, "Nama Perairan")
    luas_raw = g(prop, "Luas Kebutuhan Ruang")
    luas = format_luas_ha(luas_raw)
    jenis_kegiatan = g(prop, "Jenis Kegiatan")

    # ================= COVER =================
    jenis_permohonan = prop.get("jenis_permohonan", "Persetujuan").strip() or "Persetujuan"
    jenis_permohonan_label = "KONFIRMASI" if jenis_permohonan.lower().startswith("konfirmasi") else "PERSETUJUAN"

    title = b.doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = title.add_run("DRAFT PROPOSAL TEKNIS")
    set_font(r, size=20, bold=True, color=NAVY)

    sub = b.doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = sub.add_run(f"PERMOHONAN {jenis_permohonan_label} KESESUAIAN KEGIATAN\nPEMANFAATAN RUANG LAUT (PKKPRL)")
    set_font(r, size=14, bold=True)

    note = b.doc.add_paragraph()
    note.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = note.add_run("Disusun mengacu pada Peraturan Menteri Kelautan dan Perikanan Nomor 28 Tahun 2021 "
                     "tentang Penyelenggaraan Penataan Ruang Laut")
    set_font(r, size=10, italic=True)
    note.paragraph_format.space_after = Pt(20)

    b.kv_table([
        ("Nama Pemohon", g(prop, "Nama Pemohon")),
        ("Jabatan Pemohon", g(prop, "Jabatan Pemohon")),
        ("Nama Perusahaan/Instansi", perusahaan),
        ("NIB", g(prop, "NIB")),
        ("NPWP", g(prop, "NPWP")),
        ("Nomor Telepon Selular", g(prop, "Nomor Telepon Selular")),
        ("Surat Elektronik", g(prop, "Surat Elektronik")),
        ("Jenis Kegiatan", jenis_kegiatan),
        ("Lokasi Kegiatan", lokasi_lengkap),
        ("Nama Perairan", perairan),
        ("Luas Kebutuhan Ruang", luas),
        ("KBLI", g(prop, "KBLI")),
        ("Tanggal Penyusunan", g(prop, "Tanggal Penyusunan")),
    ])
    b.page_break()

    # ================= BAB I =================
    b.h1("I. RENCANA BANGUNAN DAN INSTALASI LAUT")
    b.h2("Pendahuluan")
    b.p(f"Proposal teknis ini disusun sebagai bagian dari persyaratan permohonan {jenis_permohonan_label.capitalize()} Kesesuaian "
        f"Kegiatan Pemanfaatan Ruang Laut (PKKPRL), sebagaimana diatur dalam Peraturan Pemerintah Nomor 21 "
        f"Tahun 2021 tentang Penyelenggaraan Penataan Ruang, Peraturan Menteri Kelautan dan Perikanan Nomor "
        f"28 Tahun 2021 tentang Penyelenggaraan Penataan Ruang Laut, serta ketentuan pelaksanaan pada sistem "
        f"OSS Berbasis Risiko.")
    b.p(f"{perusahaan} yang diwakili oleh {g(prop, 'Nama Pemohon')} berencana menyelenggarakan kegiatan "
        f"berusaha berupa {jenis_kegiatan}. Rencana kegiatan ini berlokasi di {lokasi_lengkap}, menggunakan "
        f"perairan {perairan} dengan total kebutuhan luas ruang laut yang dimohonkan sebesar {luas}.")

    b.h2("A. Rencana Kegiatan Utama dan Penunjang")
    b.h3("1. Uraian Kegiatan")
    b.p(f"Kegiatan yang dimohonkan adalah {jenis_kegiatan}, dengan kebutuhan ruang laut seluas {luas}.")
    deskripsi_keg = prop.get("deskripsi_kegiatan", "")
    if deskripsi_keg:
        b.labeled("Deskripsi Kegiatan", deskripsi_keg)
    manfaat_keg = prop.get("manfaat_kegiatan", "")
    if manfaat_keg:
        b.labeled("Manfaat Kegiatan", manfaat_keg)
    tujuan_keg = prop.get("tujuan_kegiatan", "")
    if tujuan_keg:
        b.labeled("Tujuan Kegiatan", tujuan_keg)
    invest = g(prop, "investasi")
    invest_str = f"Rp{invest}" if invest != NA else NA
    tenaga = g(prop, "tenaga_kerja")
    tenaga_asing = g(prop, "tenaga_kerja_asing", "0")
    b.p(f"Rencana tenaga kerja yang digunakan berjumlah {tenaga} orang WNI/lokal, dengan tenaga kerja asing "
        f"berjumlah {tenaga_asing}. Total komitmen pendanaan investasi kegiatan ini sebesar {invest_str}, "
        f"mencakup perencanaan teknis, pengadaan sarana-prasarana, operasional, serta pengelolaan lingkungan hidup.")

    instalasi_bangunan = prop.get("instalasi_bangunan", "")
    instalasi_posisi = prop.get("instalasi_posisi", "")
    if instalasi_bangunan or instalasi_posisi:
        posisi_txt = f", berada pada {instalasi_posisi.lower()}" if instalasi_posisi else ""
        bangunan_txt = instalasi_bangunan if instalasi_bangunan else "instalasi penunjang kegiatan"
        b.p(f"Instalasi bangunan menetap di laut yang direncanakan berupa {bangunan_txt}{posisi_txt}.")

    dukung = prop.get("dokumen_data_dukung", "")
    if dukung:
        b.p(f"Dokumen data dukung yang telah dimiliki oleh pelaku usaha meliputi: {dukung}.")

    h3_2 = b.h3("2. Kegiatan Eksisting atau Rencana yang Akan Dimohonkan")
    status_map = {
        "Eksisting": "merupakan kegiatan yang sudah berjalan (eksisting)",
        "Rencana": "merupakan kegiatan yang baru akan direncanakan",
        "Eksisting dan Pengembangan": "merupakan kegiatan eksisting yang akan dikembangkan lebih lanjut",
    }
    status_txt = status_map.get(prop.get("kegiatan_status", ""), "")
    status_sentence = f" Kegiatan ini {status_txt}." if status_txt else ""
    b.p(f"Kegiatan rencana yang dimohonkan adalah {jenis_kegiatan} yang berada di {lokasi_lengkap}, menggunakan "
        f"perairan {perairan} dengan total kebutuhan luas ruang laut sebesar {luas}.{status_sentence} Pengajuan PKKPRL dilakukan "
        f"dalam rangka pemenuhan perizinan dasar di lokasi yang dimohonkan sebelum mengajukan perizinan lanjutan.")
    img_no = 1
    siteplan_list = [im for im in prop_imgs if im["tag"] == "siteplan"]
    for idx, im in enumerate(siteplan_list):
        b.image(im["bytes"], width_cm=13)
        label = "Peta Rencana Tapak (Site Plan)" if idx == 0 else "Dokumentasi Tambahan Rencana Tapak (Site Plan)"
        b.caption(f"Gambar {img_no}. {label} Kegiatan {perusahaan}.")
        img_no += 1

    dok_kegiatan_img = get_image_bytes(prop_imgs, "dok_kegiatan_eksisting")
    if dok_kegiatan_img:
        b.image(dok_kegiatan_img, width_cm=13)
        b.caption(f"Gambar {img_no}. Dokumentasi Kegiatan Eksisting/Rencana yang Dimohonkan.")
        img_no += 1

    b.h3("3. Rencana Jadwal Pelaksanaan Kegiatan Utama dan Pendukungnya")
    jadwal_table = prop.get("jadwal_table") or []
    activities, activities_mgu, anchor_bt, rincian, ada_minggu = activities_from_jadwal_table(jadwal_table)
    if not activities:
        # kompatibel dengan draft lama yang masih pakai teks bebas "Nama : Bulan X - Bulan Y."
        activities = parse_jadwal_kegiatan(prop.get("jadwal_kegiatan", ""))
        anchor_bt = parse_tanggal_indonesia(prop.get("Tanggal Penyusunan", "")) or (
            __import__("datetime").datetime.now().month, __import__("datetime").datetime.now().year
        )
        rincian = []
        activities_mgu = []
        ada_minggu = False
    bangunan_txt2 = instalasi_bangunan if instalasi_bangunan else "instalasi penunjang kegiatan"
    posisi_txt2 = f" yang berada di {instalasi_posisi.lower()}" if instalasi_posisi else ""
    if activities:
        b.p(f"Adapun kegiatan utama yang akan dilakukan ialah pembangunan dan pengembangan lokasi {jenis_kegiatan} "
            f"akan dilakukan sebagaimana ditampilkan pada Tabel 1. Seluruh bangunan merupakan {bangunan_txt2}{posisi_txt2}.")
        if rincian:
            b.data_table(["Nama Kegiatan", "Mulai", "Selesai"], rincian)
            b.caption("Tabel 1. Rincian Waktu Pelaksanaan Kegiatan Utama dan Pendukungnya.")
        if ada_minggu:
            max_bulan = max(a[2] for a in activities)
            build_gantt_table_weekly(b, activities_mgu, anchor_bt, max_bulan)
        else:
            build_gantt_table(b, activities, anchor_bt)
        b.caption(("Tabel 2. " if rincian else "Tabel 1. ") + "Rencana Jadwal Pelaksanaan Kegiatan Utama dan Pendukungnya (Gantt Chart).")
    else:
        jadwal = prop.get("jadwal_kegiatan", "")
        if jadwal:
            b.labeled("Jadwal Kegiatan", jadwal)
        else:
            b.p(NA)

    b.h3("4. Reklamasi / Non-Reklamasi")
    if prop.get("non_reklamasi"):
        reklamasi_txt = "tanpa reklamasi"
    elif prop.get("reklamasi"):
        reklamasi_txt = "dengan reklamasi"
    else:
        reklamasi_txt = NA
    b.p(f"Kegiatan {jenis_kegiatan} yang dilakukan oleh {perusahaan} merupakan kegiatan yang dilaksanakan {reklamasi_txt}.")

    b.h2("B. Kegiatan Berusaha atau Non-Berusaha")
    if prop.get("kegiatan_berusaha"):
        berusaha_txt = "kegiatan berusaha"
    elif prop.get("non_berusaha"):
        berusaha_txt = "kegiatan non-berusaha"
    else:
        berusaha_txt = NA
    b.p(f"Kegiatan {jenis_kegiatan} yang dilakukan {perusahaan} di {lokasi_lengkap}, yang menggunakan perairan "
        f"{perairan}, merupakan {berusaha_txt}.")

    b.h2("C. Kegiatan Strategis Nasional atau Nonstrategis Nasional")
    if prop.get("strategis"):
        strategis_txt = "kegiatan strategis nasional"
    elif prop.get("non_strategis"):
        strategis_txt = "kegiatan non-strategis nasional/dasar"
    else:
        strategis_txt = NA
    b.p(f"Rencana kegiatan pemanfaatan ruang laut ini tergolong sebagai {strategis_txt}. Penetapan status ini "
        f"digunakan sebagai acuan untuk memenuhi persyaratan teknis permohonan PKKPRL.")

    b.h2("D. Peta Lokasi")
    koord = prop.get("koordinat") or []
    koord_header = prop.get("koordinat_header") or ["Nomor Titik", "Longitude", "Latitude"]
    if koord:
        b.p("Peta lokasi/plotting batas-batas area yang dimohonkan PKKPRL ditunjukkan oleh titik koordinat berikut:")
        b.data_table(koord_header, koord)
        b.caption("Tabel 1. Titik Koordinat Batas Area Permohonan PKKPRL.")
    else:
        b.p(NA)

    peta_lokasi_img = get_image_bytes(prop_imgs, "peta_lokasi")
    if peta_lokasi_img:
        b.image(peta_lokasi_img, width_cm=11)
        b.caption(f"Gambar {img_no}. Peta Lokasi dan Sebaran Titik Koordinat Rencana Kegiatan.")
        img_no += 1
    sumber_peta = prop.get("sumber_peta", "")
    if sumber_peta:
        b.caption(f"Sumber Peta: {sumber_peta}")

    b.h2("E. Deskripsi Luas/Panjang yang Dibutuhkan")
    b.p(f"Luas perairan yang dimohonkan KKPRL adalah seluas {luas} yang terletak di perairan {perairan}, "
        f"{lokasi_lengkap}.")

    b.page_break()

    # ================= BAB II =================
    b.h1("II. INFORMASI PEMANFAATAN RUANG LAUT")
    b.p(f"Berdasarkan hasil identifikasi, pemanfaatan ruang laut eksisting di sekitar lokasi kegiatan "
        f"{jenis_kegiatan} dari {perusahaan} termasuk dalam wilayah perairan {perairan}, pada administrasi "
        f"{lokasi_lengkap}.")
    b.p("Berdasarkan hasil survei/pengamatan langsung, tidak terdapat pemanfaatan ruang laut oleh pihak lain "
        "di sekitar lokasi permohonan. Rencana kegiatan disusun dengan memperhatikan kepentingan nelayan "
        "tradisional dan masyarakat, serta tidak menghalangi akses pelayaran yang sudah ada.")
    batas_utara = prop.get("batas_utara", "")
    batas_timur = prop.get("batas_timur", "")
    batas_selatan = prop.get("batas_selatan", "")
    batas_barat = prop.get("batas_barat", "")
    if batas_utara or batas_timur or batas_selatan or batas_barat:
        kalimat_arah = ["Pemanfaatan ruang laut di sekitar lokasi permohonan didominasi oleh aktivitas "
                        "penangkapan ikan skala kecil di seluruh penjuru arah mata angin."]
        if batas_utara:
            kalimat_arah.append(f"Di sebelah utara, lokasi berbatasan dengan {batas_utara}.")
        if batas_timur:
            kalimat_arah.append(f"Pada sisi timur, kawasan berbatasan dengan {batas_timur}.")
        if batas_selatan:
            kalimat_arah.append(f"Sementara itu, di sebelah selatan terdapat {batas_selatan}.")
        if batas_barat:
            kalimat_arah.append(f"Di sebelah barat berbatasan dengan {batas_barat}.")
        b.p(" ".join(kalimat_arah))

    deskripsi_sekitar = prop.get("deskripsi_pemanfaatan_sekitar", "")
    if deskripsi_sekitar:
        b.p(deskripsi_sekitar)

    foto_pantai_list = [im for im in prop_imgs if im["tag"] == "foto_pantai"]
    for idx, im in enumerate(foto_pantai_list):
        b.image(im["bytes"], width_cm=11)
        label = "Kondisi Eksisting Perairan dan Garis Pantai" if idx == 0 else "Dokumentasi Lapangan Tambahan Kondisi Garis Pantai"
        b.caption(f"Gambar {img_no}. {label} di Sekitar Lokasi Permohonan.")
        img_no += 1

    dok_sekitar_list = [im for im in prop_imgs if im["tag"] == "dok_pemanfaatan_sekitar"]
    for im in dok_sekitar_list:
        b.image(im["bytes"], width_cm=11)
        b.caption(f"Gambar {img_no}. Dokumentasi Kegiatan Pemanfaatan Ruang Laut Sekitar.")
        img_no += 1

    b.page_break()

    # ================= BAB III =================
    b.h1("III. DATA KONDISI TERKINI LOKASI DAN SEKITARNYA")

    b.h2("A. Ekosistem Sekitar")
    b.h3("1. Mangrove")
    mangrove_ada = prop.get("mangrove_ada", "")
    if mangrove_ada == "Tidak terdapat ekosistem mangrove":
        b.p("Berdasarkan hasil pengamatan langsung kondisi pesisir di sekitar lokasi kegiatan, tidak "
            "teridentifikasi keberadaan ekosistem mangrove pada area yang dimohonkan.")
    else:
        spesies = g(prop, "mangrove_spesies")
        persen_mgv = g(prop, "mangrove_persen")
        kondisi_mgv = g(prop, "mangrove_kondisi")
        b.p(f"Berdasarkan hasil pengamatan langsung kondisi pesisir di sekitar lokasi kegiatan, terdapat ekosistem "
            f"mangrove yang didominasi oleh jenis {spesies}, dengan persentase tutupan mencapai {persen_mgv}% "
            f"pada kondisi {kondisi_mgv}.")
        analisis_mgv = _enhance_ekosistem("mangrove", spesies, persen_mgv, kondisi_mgv, lokasi_lengkap)
        if analisis_mgv:
            b.p(analisis_mgv)
    mgv_img = get_image_bytes(prop_imgs, "foto_mangrove")
    if mgv_img:
        b.image(mgv_img, width_cm=11)
        if mangrove_ada == "Tidak terdapat ekosistem mangrove":
            b.caption(f"Gambar {img_no}. Kondisi Ekosistem Pesisir di Sekitar Lokasi Kegiatan.")
        else:
            b.caption(f"Gambar {img_no}. Kondisi Tutupan Vegetasi Mangrove di Sekitar Lokasi Kegiatan.")
        img_no += 1

    b.h3("2. Lamun")
    ada_lamun = lap.get("ada_lamun")
    jarak_eko = g(lap, "eko_jarak_terdekat_km")
    if ada_lamun:
        b.p(f"Berdasarkan data sekunder hasil pengamatan lapangan awal, tidak teridentifikasi keberadaan "
            f"ekosistem lamun (seagrass) secara langsung pada titik pengambilan sampel di area yang dimohonkan. "
            f"Namun demikian, berdasarkan analisis spasial basis data ekosistem nasional, ekosistem padang "
            f"lamun teridentifikasi berada di sekitar lokasi, dengan jarak ekosistem terdekat dari titik pusat "
            f"rencana kegiatan sekitar {jarak_eko} km. Disarankan verifikasi lapangan lanjutan untuk memastikan "
            f"keberadaan dan luasan ekosistem lamun secara lebih akurat.")
    else:
        b.p("Berdasarkan data sekunder perairan di sekitar lokasi kegiatan, tidak teridentifikasi keberadaan "
            "ekosistem lamun (seagrass) pada area yang dimohonkan.")

    lamun_ada_manual = prop.get("lamun_ada_manual", "")
    if lamun_ada_manual == "Terdapat ekosistem lamun":
        lamun_spesies = g(prop, "lamun_spesies")
        lamun_persen = g(prop, "lamun_persen")
        lamun_kondisi = g(prop, "lamun_kondisi")
        b.p(f"Berdasarkan hasil pengamatan pemohon di lapangan, teridentifikasi ekosistem lamun yang didominasi "
            f"oleh jenis {lamun_spesies}, dengan persentase tutupan mencapai {lamun_persen}% pada kondisi {lamun_kondisi}.")
        analisis_lamun = _enhance_ekosistem("lamun (seagrass)", lamun_spesies, lamun_persen, lamun_kondisi, lokasi_lengkap)
        if analisis_lamun:
            b.p(analisis_lamun)

    # Foto dokumentasi kondisi perairan tetap ditampilkan kalau diunggah,
    # TERLEPAS dari status ada/tidaknya ekosistem lamun -- foto ini
    # mendokumentasikan kondisi perairan lokasi (mendukung klaim "tidak
    # ditemukan" sekalipun), bukan cuma foto ekosistem lamun itu sendiri.
    lamun_img = get_image_bytes(prop_imgs, "foto_lamun")
    if lamun_img:
        b.image(lamun_img, width_cm=11)
        if lamun_ada_manual == "Terdapat ekosistem lamun":
            b.caption(f"Gambar {img_no}. Dokumentasi Ekosistem Lamun di Sekitar Lokasi Kegiatan.")
        else:
            b.caption(f"Gambar {img_no}. Dokumentasi Kondisi Perairan di Sekitar Lokasi Kegiatan.")
        img_no += 1

    b.h3("3. Terumbu Karang")
    karang_ha = g(lap, "eko_karang_ha")
    karang_pct = g(lap, "eko_karang_pct")
    lainnya_ha = g(lap, "eko_lainnya_ha")
    lainnya_pct = g(lap, "eko_lainnya_pct")
    terbuka_ha = g(lap, "eko_terbuka_ha")
    terbuka_pct = g(lap, "eko_terbuka_pct")
    total_ha = g(lap, "eko_total_ha")
    karang_terdeteksi = _ada_data_numerik(karang_ha) or _ada_data_numerik(karang_pct)
    if karang_terdeteksi:
        b.p(f"Hasil survei in-situ pada perairan di sekitar lokasi menunjukkan dijumpainya koloni terumbu karang "
            f"pada beberapa titik substrat berbatu. Berdasarkan analisis spasial basis data ekosistem, dari total "
            f"area kajian seluas {total_ha} Ha, tutupan terumbu karang tercatat seluas {karang_ha} Ha ({karang_pct}%), "
            f"diikuti substrat dasar non-terumbu seluas {lainnya_ha} Ha ({lainnya_pct}%), dan area laut terbuka "
            f"tanpa ekosistem seluas {terbuka_ha} Ha ({terbuka_pct}%).")
        kondisi_karang_lap = klasifikasi_karang(karang_pct)
        if kondisi_karang_lap:
            b.p(f"Berdasarkan kriteria baku kerusakan terumbu karang, persentase tutupan sebesar {karang_pct}% "
                f"tersebut tergolong pada kategori kondisi \u201c{kondisi_karang_lap}\u201d.")
        b.data_table(
            ["Jenis Tutupan", "Luas (Ha)", "Persentase (%)"],
            [
                ["Terumbu Karang", karang_ha, karang_pct],
                ["Lainnya (substrat dasar non-terumbu)", lainnya_ha, lainnya_pct],
                ["Area Laut Terbuka (tanpa ekosistem)", terbuka_ha, terbuka_pct],
                ["Total Area Kajian", total_ha, "100,0"],
            ],
        )
        b.caption("Tabel 2. Rincian Tutupan Ekosistem pada Area Kajian Spasial di Sekitar Titik Pusat Rencana Kegiatan.")
    else:
        b.p("Berdasarkan data sekunder perairan di sekitar lokasi kegiatan, tidak teridentifikasi keberadaan "
            "ekosistem terumbu karang pada area yang dimohonkan.")

    karang_ada_manual = prop.get("karang_ada", "")
    if karang_ada_manual == "Terdapat ekosistem terumbu karang":
        karang_spesies_m = g(prop, "karang_spesies")
        karang_persen_m = g(prop, "karang_persen_manual")
        karang_kondisi_m = g(prop, "karang_kondisi")
        b.p(f"Berdasarkan hasil pengamatan pemohon di lapangan, teridentifikasi ekosistem terumbu karang yang "
            f"didominasi oleh jenis {karang_spesies_m}, dengan persentase tutupan mencapai {karang_persen_m}% "
            f"pada kondisi {karang_kondisi_m}.")
        analisis_karang = _enhance_ekosistem(
            "terumbu karang", karang_spesies_m, karang_persen_m, karang_kondisi_m, lokasi_lengkap
        )
        if analisis_karang:
            b.p(analisis_karang)
    elif karang_ada_manual == "Tidak terdapat ekosistem terumbu karang":
        b.p("Berdasarkan hasil pengamatan pemohon di lapangan, tidak teridentifikasi keberadaan ekosistem "
            "terumbu karang secara langsung pada area yang dimohonkan.")

    karang_img = get_image_bytes(prop_imgs, "foto_karang_insitu")
    if karang_img:
        b.image(karang_img, width_cm=11)
        b.caption(f"Gambar {img_no}. Dokumentasi Survei In-Situ Koloni Terumbu Karang di Perairan Sekitar Lokasi Kegiatan.")
        img_no += 1

    eko_img = get_image_bytes(lap_imgs, "peta_ekosistem")
    if eko_img:
        b.image(eko_img, width_cm=11)
        b.caption(f"Gambar {img_no}. Peta Sebaran Spasial Ekosistem Pesisir di Sekitar Titik Pusat Rencana Kegiatan.")
        img_no += 1
    b.p(f"Jarak ekosistem terdekat dari titik pusat rencana kegiatan adalah {jarak_eko} km, sehingga mitigasi "
        f"dampak perlu difokuskan pada upaya penghindaran (avoidance) terhadap area terumbu karang, pengendalian "
        f"sedimen, serta pengelolaan kualitas air.")
    narasi_lap_eko = lap.get("_narasi", {}) or {}
    if narasi_lap_eko.get("ekosistem"):
        b.p(_enhance_narasi(narasi_lap_eko["ekosistem"], konteks="analisis ekosistem pesisir"))

    b.h2("B. Hidro-Oseanografi")
    narasi_lap = lap.get("_narasi", {}) or {}
    b.h3("1. Gelombang")
    b.p(f"Tinggi gelombang signifikan (Hs) rata-rata tercatat sebesar {g(lap,'hs_rata')} meter, sedangkan Hs "
        f"maksimum ekstrem tercatat sebesar {g(lap,'hs_maks')} meter dengan arah dominan dari "
        f"{g(lap,'hs_arah')}\u00b0. Parameter ini menjadi acuan utama dalam desain ketahanan struktur bangunan laut "
        f"terhadap beban gelombang ekstrem.")
    if narasi_lap.get("gelombang"):
        b.p(_enhance_narasi(narasi_lap["gelombang"], konteks="analisis gelombang laut"))
    gel_img = get_image_bytes(lap_imgs, "mawar_gelombang")
    if gel_img:
        b.image(gel_img, width_cm=9)
        b.caption(f"Gambar {img_no}. Mawar Gelombang Ekstrem pada Titik Pusat Rencana Kegiatan (Arah Dominan {g(lap,'hs_arah')}\u00b0).")
        img_no += 1

    b.h3("2. Arus")
    b.p(f"Kecepatan arus rata-rata tercatat sebesar {g(lap,'arus_rata')} m/detik, dengan kecepatan maksimum "
        f"ekstrem sebesar {g(lap,'arus_maks')} m/detik dan arah dominan dari {g(lap,'arus_arah')}\u00b0. Parameter "
        f"ini menjadi indikator potensi gerusan (scouring) di sekitar struktur bangunan laut.")
    if narasi_lap.get("arus"):
        b.p(_enhance_narasi(narasi_lap["arus"], konteks="analisis arus laut"))
    arus_img = get_image_bytes(lap_imgs, "mawar_arus")
    if arus_img:
        b.image(arus_img, width_cm=9)
        b.caption(f"Gambar {img_no}. Mawar Arus pada Titik Pusat Rencana Kegiatan (Arah Dominan {g(lap,'arus_arah')}\u00b0).")
        img_no += 1

    b.data_table(
        ["Parameter", "Nilai Rata-rata", "Nilai Ekstrem", "Arah Dominan"],
        [
            ["Tinggi Gelombang Signifikan (Hs)", f"{g(lap,'hs_rata')} m", f"{g(lap,'hs_maks')} m", f"{g(lap,'hs_arah')}\u00b0"],
            ["Kecepatan Arus", f"{g(lap,'arus_rata')} m/detik", f"{g(lap,'arus_maks')} m/detik", f"{g(lap,'arus_arah')}\u00b0"],
        ],
    )
    b.caption("Tabel 3. Ringkasan Parameter Gelombang dan Arus pada Titik Pusat Rencana Kegiatan.")

    b.h3("3. Pasang Surut")
    b.p(f"Perairan ini memiliki tipe pasang surut {g(lap,'tipe_pasut')} (Bilangan Formzahl {g(lap,'formzahl')}), "
        f"dengan tunggang air (tidal range) sebesar {g(lap,'tidal_range')} meter, elevasi tertinggi (HAT) "
        f"sebesar +{g(lap,'hat')} meter, dan elevasi terendah (LAT) sebesar {g(lap,'lat')} meter.")
    if narasi_lap.get("pasut"):
        b.p(_enhance_narasi(narasi_lap["pasut"], konteks="analisis pasang surut"))
    b.data_table(
        ["Parameter Pasang Surut", "Elevasi"],
        [
            ["Highest Astronomical Tide (HAT)", f"+{g(lap,'hat')} m"],
            ["Mean Sea Level (MSL)", f"{g(lap,'msl')} m"],
            ["Lowest Astronomical Tide (LAT)", f"{g(lap,'lat')} m"],
            ["Tidal Range", f"{g(lap,'tidal_range')} m"],
            ["Bilangan Formzahl", f"{g(lap,'formzahl')} ({g(lap,'tipe_pasut')})"],
        ],
    )
    b.caption("Tabel 4. Parameter Pasang Surut pada Lokasi Kegiatan.")
    pasut_img = get_image_bytes(lap_imgs, "siklus_pasut")
    if pasut_img:
        b.image(pasut_img, width_cm=13)
        b.caption(f"Gambar {img_no}. Grafik Fluktuasi Pasang Surut Selama 14 Hari (Tipe {g(lap,'tipe_pasut')}).")
        img_no += 1

    b.h2("C. Profil Dasar Laut")
    b.p(f"Kedalaman pada titik pusat lokasi kegiatan tercatat sebesar {g(lap,'batimetri_titik_pusat')} meter "
        f"terhadap Lowest Water Spring (LWS). Hasil pemeruman pada profil garis batimetri sepanjang lintasan "
        f"{g(lap,'batimetri_panjang_lintasan')} km menunjukkan kedalaman terdalam mencapai "
        f"{g(lap,'batimetri_terdalam')} meter.")
    if narasi_lap.get("batimetri"):
        b.p(_enhance_narasi(narasi_lap["batimetri"], konteks="analisis profil batimetri/dasar laut"))
    bati_img = get_image_bytes(lap_imgs, "profil_batimetri")
    if bati_img:
        b.image(bati_img, width_cm=13)
        b.caption(f"Gambar {img_no}. Profil Garis Batimetri pada Lintasan Pemeruman Titik Pusat Rencana Kegiatan.")
        img_no += 1

    b.h2("D. Kondisi Sosial Ekonomi Masyarakat")
    sumber_sosek = prop.get("sumber_data_sosek", "") or "Badan Pusat Statistik"
    tahun_sosek = prop.get("tahun_data_sosek", "")
    tahun_txt = f" tahun {tahun_sosek}" if tahun_sosek else ""
    b.p(f"Berdasarkan data sekunder {sumber_sosek}{tahun_txt}, {desa} memiliki luas wilayah {g(prop,'desa_luas_ha')} "
        f"Ha dengan jumlah penduduk sebanyak {g(prop,'desa_penduduk')} jiwa. Kehadiran rencana kegiatan ini "
        f"diharapkan dapat mendukung struktur sosial-ekonomi kawasan secara harmonis dan melibatkan konsultasi "
        f"publik dengan kelompok nelayan setempat sebelum pelaksanaan konstruksi.")
    mata_pencaharian = prop.get("mata_pencaharian", "")
    if mata_pencaharian:
        b.labeled("Mata Pencaharian Masyarakat Desa", mata_pencaharian)

    b.h2("E. Aksesibilitas Lokasi dan Sekitarnya")
    aksesibilitas_manual = prop.get("aksesibilitas_lokasi", "")
    if aksesibilitas_manual:
        b.p(aksesibilitas_manual)
    else:
        b.p(f"Aksesibilitas menuju lokasi kegiatan di {lokasi_lengkap} dapat ditempuh melalui jalur darat maupun laut.")

    akses_img = get_image_bytes(prop_imgs, "gambar_aksesibilitas")
    if akses_img:
        b.image(akses_img, width_cm=13)
        b.caption(f"Gambar {img_no}. Peta Aksesibilitas Menuju Lokasi Kegiatan.")
        img_no += 1

    pola_img = get_image_bytes(prop_imgs, "peta_pola_ruang")
    if pola_img:
        b.image(pola_img, width_cm=13)
        b.caption(f"Gambar {img_no}. Peta Rencana Pola Ruang Wilayah dan Posisi Lokasi Permohonan.")
        img_no += 1

    b.page_break()
    b.h1("IV. DOKUMEN PERSYARATAN LAINNYA")
    b.p(f"Dokumen pendukung untuk permohonan PKKPRL yang diajukan oleh {perusahaan} meliputi:")

    dukung_detail = prop.get("dokumen_data_dukung_detail") or []
    if dukung_detail:
        for item in dukung_detail:
            label = item.get("label", "")
            drive = item.get("drive", "")
            fname = item.get("file", "")
            if drive:
                b.bullet_with_link(f"{label}. (tautan Google Drive: ", drive, drive, ")")
            elif fname:
                b.bullet(f"{label}. (file terlampir: {fname} \u2013 lihat lampiran halaman berikut)")
            else:
                b.bullet(f"{label}.")
    else:
        b.p(NA)

    sertifikat_img = get_image_bytes(prop_imgs, "sertifikat_lahan")
    if sertifikat_img:
        b.image(sertifikat_img, width_cm=13)
        b.caption(f"Gambar {img_no}. Sertifikat Kepemilikan Lahan Darat.")
        img_no += 1

    sosialisasi_img = get_image_bytes(prop_imgs, "dok_sosialisasi")
    if sosialisasi_img:
        b.image(sosialisasi_img, width_cm=13)
        b.caption(f"Gambar {img_no}. Dokumen Hasil Sosialisasi dengan Masyarakat Sekitar.")
        img_no += 1

    dukung_dok_list = [im for im in prop_imgs if im["tag"] == "dukung_dokumen"]
    for im in dukung_dok_list:
        b.image(im["bytes"], width_cm=13)
        b.caption(f"Gambar {img_no}. {im.get('caption') or 'Dokumen Data Dukung Terlampir.'}")
        img_no += 1

    pendukung_lain_list = [im for im in prop_imgs if im["tag"] == "dok_pendukung_lainnya"]
    for im in pendukung_lain_list:
        b.image(im["bytes"], width_cm=13)
        b.caption(f"Gambar {img_no}. Dokumen Pendukung Lainnya.")
        img_no += 1

    b.p(f"Demikian proposal teknis ini disusun sebagai bagian dari kelengkapan administrasi dan teknis "
        f"permohonan PKKPRL atas nama {perusahaan}.", italic=True)
    b.p("Catatan: Dokumen ini dibangkitkan otomatis oleh aplikasi penggabung proposal PKKPRL dari dua sumber "
        "dokumen. Mohon verifikasi kembali seluruh data dan gambar sebelum digunakan untuk pengajuan resmi.",
        italic=True)

    b.save(output_path)
    return img_no - 1


# ---------------------------------------------------------------------------
# Konversi laporan Markdown (hasil fitur "Analisis & Koreksi Proposal") ke
# dokumen Word, supaya pengguna bisa mengunduh & mengarsipkan hasil analisis.
# Parser ini sengaja dibuat sederhana & khusus untuk format Markdown yang
# dihasilkan oleh prompt di llm_fallback.analisis_konsistensi_proposal
# (heading ##, tabel |...|, list bernomor/bullet, teks tebal **...**) --
# bukan konverter Markdown umum.
# ---------------------------------------------------------------------------
_MD_BOLD_RE = re.compile(r"(\*\*[^*]+\*\*)")
_MD_SEP_ROW_RE = re.compile(r"^:?-{2,}:?$")


def _md_add_inline(paragraph, text, bold_all=False):
    for part in _MD_BOLD_RE.split(text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            run = paragraph.add_run(part[2:-2])
            run.bold = True
        else:
            run = paragraph.add_run(part)
            if bold_all:
                run.bold = True
        run_font = run.font
        run_font.name = FONT


def markdown_report_to_docx_bytes(markdown_text, judul="Hasil Analisis & Koreksi Proposal",
                                   subjudul=None):
    """Ubah teks Markdown hasil analisis Claude (## heading, tabel, list)
    menjadi dokumen Word rapi. Mengembalikan bytes file .docx (siap dikirim
    lewat send_file/BytesIO)."""
    doc = Document()
    for section in doc.sections:
        section.top_margin = Cm(2.2)
        section.bottom_margin = Cm(2.2)
        section.left_margin = Cm(2.5)
        section.right_margin = Cm(2.2)

    title_p = doc.add_paragraph()
    title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_run = title_p.add_run(judul)
    title_run.bold = True
    title_run.font.size = Pt(16)
    title_run.font.color.rgb = NAVY
    title_run.font.name = FONT

    if subjudul:
        sub_p = doc.add_paragraph()
        sub_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        sub_run = sub_p.add_run(subjudul)
        sub_run.italic = True
        sub_run.font.size = Pt(10.5)
        sub_run.font.name = FONT

    doc.add_paragraph()

    lines = (markdown_text or "").replace("\r\n", "\n").split("\n")
    i, n = 0, len(lines)
    while i < n:
        line = lines[i].rstrip()
        stripped = line.strip()

        if not stripped:
            i += 1
            continue

        if stripped.startswith("## "):
            h = doc.add_heading(stripped[3:].strip(), level=1)
            for run in h.runs:
                run.font.color.rgb = NAVY
                run.font.name = FONT
            i += 1
            continue

        if stripped.startswith("### "):
            h = doc.add_heading(stripped[4:].strip(), level=2)
            for run in h.runs:
                run.font.name = FONT
            i += 1
            continue

        if stripped.startswith("|"):
            table_lines = []
            while i < n and lines[i].strip().startswith("|"):
                table_lines.append(lines[i].strip())
                i += 1
            rows = []
            for tl in table_lines:
                cells = [c.strip() for c in tl.strip("|").split("|")]
                if cells and all(_MD_SEP_ROW_RE.match(c) for c in cells):
                    continue
                rows.append(cells)
            if rows:
                ncols = max(len(r) for r in rows)
                table = doc.add_table(rows=len(rows), cols=ncols)
                try:
                    table.style = "Light Grid Accent 1"
                except KeyError:
                    pass
                for r, row in enumerate(rows):
                    for c in range(ncols):
                        cell_text = row[c] if c < len(row) else ""
                        cell = table.cell(r, c)
                        cell.text = ""
                        p = cell.paragraphs[0]
                        _md_add_inline(p, cell_text, bold_all=(r == 0))
                        if r == 0:
                            shading = OxmlElement("w:shd")
                            shading.set(qn("w:fill"), "1F4E79")
                            cell._tc.get_or_add_tcPr().append(shading)
                            for run in p.runs:
                                run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
                doc.add_paragraph()
            continue

        if re.match(r"^\d+\.\s", stripped):
            p = doc.add_paragraph(style="List Number")
            _md_add_inline(p, re.sub(r"^\d+\.\s", "", stripped))
            i += 1
            continue

        if stripped.startswith("- ") or stripped.startswith("* "):
            p = doc.add_paragraph(style="List Bullet")
            _md_add_inline(p, stripped[2:].strip())
            i += 1
            continue

        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        _md_add_inline(p, stripped)
        i += 1

    bio = io.BytesIO()
    doc.save(bio)
    bio.seek(0)
    return bio.getvalue()
