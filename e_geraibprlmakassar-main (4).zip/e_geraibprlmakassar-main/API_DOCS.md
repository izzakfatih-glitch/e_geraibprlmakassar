# REST API — e-GerAI KKPRL BPRL Makassar

API JSON terpisah dari halaman web yang sudah ada, untuk tiga fitur:

1. **Asisten Tanya-Jawab KKPRL** (`/api/v1/asisten/*`)
2. **Generate Dokumen Proposal Teknis PKKPRL** (`/api/v1/dokumen/*`)
3. **Analisis & Koreksi Proposal** (`/api/v1/analisis/*`) — padanan API dari
   halaman web `/analisis-proposal` (audit konsistensi Proposal vs Laporan
   pembanding lewat Claude, plus simpan/riwayat/unduh hasil analisis)

Tersedia dalam **dua implementasi** (endpoint, request/response,
autentikasi, dan kode error identik untuk fitur 1–2 — pilih salah satu
sesuai kebutuhan):

| File | Framework | Cara jalan |
| --- | --- | --- |
| `api.py` | Flask Blueprint | Dipasang ke `app.py` yang sudah ada (satu proses dengan halaman web) — hanya fitur 1 & 2 |
| `api_fastapi.py` | FastAPI (ASGI) | Berdiri sendiri lewat `uvicorn`, terpisah dari `app.py` — lengkap, termasuk fitur 3 |
| `main.py` | FastAPI + Flask | **Untuk produksi (Railway/Render/Procfile)**: gabungan keduanya dalam 1 proses — `/api/v1/*` → FastAPI (termasuk fitur 3), sisanya → Flask |

Base URL: `https://<domain-anda>/api/v1`

> **Penting untuk Railway/Render:** platform tersebut menjalankan SATU start
> command per service (lihat `Procfile`). Pakai `main.py`
> (`uvicorn main:app --host 0.0.0.0 --port $PORT --workers 4`) supaya halaman
> web **dan** API `/api/v1/*` sama-sama terlayani di domain yang sama.
> Kalau start command masih `gunicorn ... app:app`, hanya halaman web yang
> jalan dan semua request `/api/v1/*` akan membalas **404**.

---

## Opsi A — Flask Blueprint (`api.py`)

1. Copy `api.py` ke folder root project (sejajar dengan `app.py`, `extract.py`, dst).
2. Terapkan `app.py.patch` ke `app.py`, atau tambahkan manual 2 potongan berikut:

   a) Tepat setelah `app = Flask(__name__)` dibuat:
   ```python
   from api import api_bp
   app.register_blueprint(api_bp)
   ```

   b) Ganti baris `PUBLIC_PREFIXES` (dekat `PUBLIC_PATHS`) menjadi:
   ```python
   PUBLIC_PREFIXES = ("/static/", "/api/v1/")
   ```
   (Ini wajib — kalau tidak, semua endpoint `/api/v1/*` akan ikut diblokir oleh halaman login pegawai yang berlaku untuk seluruh aplikasi.)

3. (Opsional tapi disarankan) Set environment variable `API_KEY` di server (Render/Railway/VPS) dengan nilai rahasia bebas Anda pilih. Kalau diset, semua endpoint (kecuali `/health`) wajib menyertakan header `X-API-Key`. Kalau tidak diset, API terbuka tanpa autentikasi — cocok untuk uji coba lokal saja.

Tidak ada perubahan lain pada `app.py` — semua route/halaman web yang sudah ada tetap jalan seperti biasa.

---

## Opsi B — FastAPI mandiri (`api_fastapi.py`)

Cocok kalau Anda ingin API JSON ini berjalan sebagai service terpisah dari
halaman web Flask (mis. di port/host/proses berbeda), dengan dokumentasi
interaktif otomatis (Swagger UI) bawaan FastAPI.

1. Install dependency tambahan (sudah ada di `requirements.txt`):
   ```bash
   pip install fastapi "uvicorn[standard]" python-multipart
   ```
2. Jalankan:
   ```bash
   uvicorn api_fastapi:app --host 0.0.0.0 --port 8001
   ```
   Untuk produksi (multi-worker), pakai:
   ```bash
   uvicorn api_fastapi:app --host 0.0.0.0 --port $PORT --workers 4
   ```
3. Dokumentasi interaktif otomatis tersedia di `/docs` (Swagger) dan `/redoc`.
4. Autentikasi sama seperti Opsi A: set `API_KEY` (dan `ANTHROPIC_API_KEY`
   untuk fitur asisten) sebagai environment variable di server yang sama.
5. File ini berdiri sendiri — **tidak perlu** menyentuh `app.py` sama
   sekali. Jalankan `app.py` (Flask, halaman web) dan `api_fastapi.py`
   (FastAPI, JSON API) sebagai dua proses terpisah (bisa di port berbeda
   pada mesin/host yang sama, atau di-deploy sebagai dua service terpisah
   di platform hosting Anda).

Semua contoh `curl` di bawah berlaku sama persis untuk kedua opsi — cukup
arahkan ke base URL/port service yang sedang Anda jalankan.

---

## Autentikasi

Kalau `API_KEY` diset di server, sertakan header di setiap request:
```
X-API-Key: <nilai API_KEY>
```
Tanpa/salah header → `401 Unauthorized`.

---

## 1) Asisten Tanya-Jawab KKPRL

### `GET /api/v1/asisten/status`
Cek apakah asisten aktif (`ANTHROPIC_API_KEY` sudah diset di server).

```bash
curl https://domain-anda/api/v1/asisten/status -H "X-API-Key: xxx"
```
```json
{ "success": true, "data": { "aktif": true } }
```

### `POST /api/v1/asisten/chat`
Kirim riwayat percakapan, dapat balasan asisten.

```bash
curl -X POST https://domain-anda/api/v1/asisten/chat \
  -H "Content-Type: application/json" -H "X-API-Key: xxx" \
  -d '{
    "messages": [
      {"role": "user", "content": "Apa itu KKPRL?"}
    ]
  }'
```
```json
{ "success": true, "data": { "reply": "KKPRL adalah ..." } }
```
- `messages`: array, urut lama → baru, pesan terakhir wajib `role: "user"`.
- Kalau `ANTHROPIC_API_KEY` belum diset di server, `reply` otomatis berisi pesan "asisten belum aktif" (tidak error).

---

## 2) Generate Dokumen (Proposal Teknis PKKPRL)

Alur: **ekstrak → (opsional koreksi) → generate**.

### `GET /api/v1/dokumen/fields`
Daftar field yang bisa dikoreksi sebelum generate (dipakai untuk tahu nama field yang valid).

```bash
curl https://domain-anda/api/v1/dokumen/fields -H "X-API-Key: xxx"
```
```json
{
  "success": true,
  "data": {
    "groups": [
      {
        "group": "Identitas Pemohon",
        "fields": [
          {"field_name": "prop__Nama_Pemohon", "source": "prop", "key": "Nama Pemohon", "label": "Nama Pemohon"},
          ...
        ]
      },
      ...
    ]
  }
}
```

### `POST /api/v1/dokumen/ekstrak`
Upload 2 file (`multipart/form-data`), server mengekstrak datanya.

```bash
curl -X POST https://domain-anda/api/v1/dokumen/ekstrak \
  -H "X-API-Key: xxx" \
  -F "proposal=@draft_proposal.pdf" \
  -F "laporan=@laporan_hidro.pdf"
```
```json
{
  "success": true,
  "data": {
    "job_id": "fdeb308be6c7",
    "prop_data": { "Nama Pemohon": "...", "...": "..." },
    "lap_data": { "eko_total_ha": "...", "...": "..." },
    "expires_in_seconds": 7200
  }
}
```
- Format file: PDF atau `.docx`.
- `job_id` berlaku ±2 jam, dipakai di langkah berikutnya.

### `POST /api/v1/dokumen/generate`
Bangun dokumen Word final dari `job_id`, dengan koreksi opsional.

```bash
curl -X POST https://domain-anda/api/v1/dokumen/generate \
  -H "Content-Type: application/json" -H "X-API-Key: xxx" \
  -d '{
    "job_id": "fdeb308be6c7",
    "koreksi": {
      "prop__Nama_Pemohon": "Budi Santoso",
      "lap__eko_total_ha": "12.5"
    }
  }' \
  -o Proposal_Final.docx
```
- Response sukses: **file `.docx` langsung** (bukan JSON) — simpan output curl langsung ke file (`-o`).
- Response gagal: JSON `{ "success": false, "error": {...} }`.
- `koreksi` opsional; nama field ikuti hasil `GET /dokumen/fields` (`field_name`).
- Job otomatis dihapus dari server setelah generate berhasil (sekali pakai).

### `DELETE /api/v1/dokumen/job/{job_id}`
Batalkan job yang belum di-generate (housekeeping opsional).

---

## 3) Analisis & Koreksi Proposal

Padanan API dari halaman web `/analisis-proposal`. Alurnya sama: unggah
Proposal (wajib) + Laporan pembanding (opsional, bisa banyak berkas) →
server mengekstrak teks semua berkas → Claude audit konsistensinya →
hasil berupa Markdown.

> Endpoint di section ini hanya ada di implementasi FastAPI
> (`api_fastapi.py` / `main.py`), tidak di Flask Blueprint `api.py`.

### `POST /api/v1/analisis/proposal`
Jalankan analisis. Multipart/form-data — field `proposal`/`laporan` boleh
diulang untuk multiple berkas (masing-masing maks 10).

```bash
curl -X POST https://domain-anda/api/v1/analisis/proposal \
  -H "X-API-Key: xxx" \
  -F "proposal=@proposal_teknis_v3.pdf" \
  -F "proposal=@lampiran_gambar.xlsx" \
  -F "laporan=@laporan_hidro.pdf"
```
```json
{
  "success": true,
  "data": {
    "hasil_markdown": "## Ringkasan\n...",
    "nama_proposal": "proposal_teknis_v3.pdf, lampiran_gambar.xlsx",
    "nama_laporan": "laporan_hidro.pdf"
  }
}
```
- `proposal` wajib (1–10 berkas), `laporan` opsional (0–10 berkas).
- Format: PDF, `.docx`, `.xlsx`, `.xlsm`. Total request maksimal 30 MB.
- Butuh `ANTHROPIC_API_KEY` di server (kalau kosong → error
  `analysis_failed` dengan keterangan).
- `hasil_markdown` dikirim apa adanya ke endpoint `unduh`/`simpan` di bawah.

### `POST /api/v1/analisis/unduh`
Ubah hasil analisis menjadi file Word.

```bash
curl -X POST https://domain-anda/api/v1/analisis/unduh \
  -H "Content-Type: application/json" -H "X-API-Key: xxx" \
  -d '{"hasil_markdown": "...", "nama_proposal": "proposal_v3.pdf"}' \
  -o Analisis_Proposal.docx
```
- Response sukses: **file `.docx` langsung** (bukan JSON).

### `POST /api/v1/analisis/simpan`
Simpan hasil analisis permanen di server (tombol "Simpan Hasil Analisis").

```bash
curl -X POST https://domain-anda/api/v1/analisis/simpan \
  -H "Content-Type: application/json" -H "X-API-Key: xxx" \
  -d '{"hasil_markdown": "...", "nama_proposal": "proposal_v3.pdf", "disimpan_oleh": "budi"}'
```
```json
{ "success": true, "data": { "entry_id": "edf527af2e6a" } }
```
- `disimpan_oleh` opsional (penanda petugas/pengguna — API tidak punya
  sesi login, jadi isi manual agar bisa difilter via `?disimpan_oleh=`).
- Simpan ke disk lokal container — kalau hosting pakai filesystem
  ephemeral (Railway), data bisa hilang saat redeploy.

### `GET /api/v1/analisis/riwayat`
Daftar hasil tersimpan. Query opsional: `disimpan_oleh` (filter petugas),
`limit` (default 200, maks 500). Tanpa filter, semua entri ikut
dikembalikan.

```bash
curl "https://domain-anda/api/v1/analisis/riwayat?disimpan_oleh=budi&limit=50" \
  -H "X-API-Key: xxx"
```
```json
{ "success": true, "data": { "items": [{"id": "edf527af2e6a", "waktu": "...", "nama_proposal": "...", ...}], "total": 1 } }
```

### `GET /api/v1/analisis/riwayat/{entry_id}`
Lihat satu hasil lengkap → `{ "meta": {...}, "hasil_markdown": "..." }`.

### `GET /api/v1/analisis/riwayat/{entry_id}/unduh`
Unduh hasil tersimpan sebagai file `.docx`.

### `DELETE /api/v1/analisis/riwayat/{entry_id}`
Hapus permanen satu hasil → `{ "deleted": true, "entry_id": "..." }`.
Kalau tidak ada → 404 `entry_not_found`.

---

## Format Error

Semua error (kecuali sukses download file) berbentuk:
```json
{
  "success": false,
  "error": { "code": "invalid_messages", "message": "Penjelasan dalam Bahasa Indonesia" }
}
```

Kode umum: `unauthorized` (401), `missing_files` / `invalid_file_type` / `too_many_files` / `no_text` / `missing_job_id` / `invalid_job_id` / `invalid_koreksi` / `invalid_messages` / `invalid_input` / `invalid_limit` / `invalid_entry_id` / `validation_error` (400), `job_not_found` / `entry_not_found` (404), `payload_too_large` (413), `extraction_failed` / `generate_failed` / `analysis_failed` / `docx_failed` / `save_failed` / `internal_error` (500).

---

## Status Pengujian

Sudah diuji end-to-end secara lokal:
- `GET /health`, `GET /asisten/status` ✔
- `POST /asisten/chat` (respons normal & fallback saat API key kosong, validasi input) ✔
- `GET /dokumen/fields` ✔
- `POST /dokumen/ekstrak` → `POST /dokumen/generate` (menghasilkan file `.docx` valid, koreksi field diterapkan) ✔
- `POST /analisis/proposal` (analisis asli ke Claude dari berkas `.docx`, `hasil_markdown` berisi laporan audit) ✔
- `POST /analisis/unduh` & `/riwayat/{id}/unduh` (menghasilkan `.docx` valid) ✔
- `POST /analisis/simpan` → `GET /riwayat` → `GET /riwayat/{id}` → `DELETE /riwayat/{id}` (404 saat dihapus dua kali) ✔
- Validasi analisis: tanpa file, ekstensi salah, >10 berkas, `limit` bukan angka ✔
- Anti path-traversal `job_id`/`entry_id` (mis. `..` ditolak 400) ✔
- Proteksi `X-API-Key` (401 tanpa/salah key, 200 dengan key benar) ✔
- Halaman web yang sudah ada (`/`, dsb) tidak terganggu ✔
